/********************************************************* {COPYRIGHT-TOP} ***
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corporation 2024
 *
 * All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 ********************************************************** {COPYRIGHT-END} **/
import { Config } from '@backstage/config';
import { IbmApicConfig } from './types';

export function readIbmApicEntityConfigs(config: Config): IbmApicConfig[] {
  const configs: IbmApicConfig[] = [];

  const providerConfigs = config.getOptionalConfigArray(
    'ibm-apic',
  );

  // No config added yet just return an empty config object and do no processing
  if (!providerConfigs) {
    return configs;
  }

  // Read each instance apicConfig added under ibm-apic key
  for (const apicConfig of providerConfigs) {
    configs.push(readIbmApicEntityConfig(apicConfig));
  }

  return configs;
}

function readIbmApicEntityConfig(config: Config): IbmApicConfig {
    return {
      'id': config.get('name'),
      'url': config.get('url'),
      'clientId': config.get('clientId'),
      'clientSecret': config.get('clientSecret'),
      'username': config.get('username'),
      'password': config.get('password'),
      'schedule': config.getOptional('schedule'),
    };
  }
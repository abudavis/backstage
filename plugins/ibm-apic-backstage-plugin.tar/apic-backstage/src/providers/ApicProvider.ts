/********************************************************* {COPYRIGHT-TOP} ***
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corporation 2024
 *
 * All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 ********************************************************** {COPYRIGHT-END} **/
import { Config } from '@backstage/config';
import {
  EntityProvider,
  EntityProviderConnection,
} from '@backstage/plugin-catalog-node';

import { readIbmApicEntityConfigs } from './config';
import { IbmApicConfig } from './types';
import { CacheService, SchedulerServiceTaskRunner, SchedulerService, LoggerService } from '@backstage/backend-plugin-api';
import { ProductEntity } from '../lib/types';

import {
  ApiEntity,
  SystemEntity
} from '@backstage/catalog-model';
import { collectAPIEntities, collectCatalogEntities, collectOrgEntities, collectProductEntities, createAPICDomain, createInstanceDomain } from '../lib/ApicDataCollector';

export class ApicProvider implements EntityProvider {
  private cache: CacheService;
  private config: IbmApicConfig;
  private env: string;

  private readonly logger: LoggerService;

  private connection?: EntityProviderConnection;
  private readonly scheduleFn: () => Promise<void>;

  /** [1] */
  private constructor(config: IbmApicConfig, logger: LoggerService, taskRunner: SchedulerServiceTaskRunner, cache: CacheService) {
    this.config = config;
    this.env = config.id;

    logger.debug(this.getProviderName())

    this.logger = logger.child({
      target: this.getProviderName(),
    });
    this.scheduleFn = this.createScheduleFn(taskRunner);
    this.cache = cache;
  }

  private createScheduleFn(taskRunner: SchedulerServiceTaskRunner): () => Promise<void> {
    return async () => {
      const taskId = `${this.getProviderName()}:run`;
      return taskRunner.run({
        id: taskId,
        fn: async () => {
          try {
            await this.run();
          } catch (error: any) {
            this.logger.error(error);
          }
        },
      });
    };
  }

  static fromConfig(
    configRoot: Config,
    options: {
      logger: LoggerService;
      schedule: SchedulerServiceTaskRunner;
      scheduler?: SchedulerService;
      cache: CacheService;
    }) : ApicProvider[] {

    const IbmApicInstanceConfigs = readIbmApicEntityConfigs(configRoot);

    if (!options.schedule && !options.scheduler) {
      throw new Error('Either schedule or scheduler must be provided.');
    }

    return IbmApicInstanceConfigs.map(IbmApicInstanceConfig => {

      if (!options.schedule && !IbmApicInstanceConfig.schedule) {
        throw new Error(
          `No schedule provided via config for ibm-apic:${IbmApicInstanceConfig.id}.`,
        );
      }

      const taskRunner = IbmApicInstanceConfig.schedule !== undefined ? options.scheduler!.createScheduledTaskRunner({ frequency: { cron: IbmApicInstanceConfig.schedule}, timeout: { seconds: 30 }}) : options!.schedule;

      return new ApicProvider(
        IbmApicInstanceConfig,
        options.logger,
        taskRunner,
        options.cache,
      );
    });
  }

  getProviderName(): string {
    return `ibm-apic:${this.config.id}`;
  }

  async connect(connection: EntityProviderConnection): Promise<void> {
    this.connection = connection;
    await this.scheduleFn();
  }

  async run(): Promise<void> {
    this.logger.info('Running Scheduled APIC Provider Code')

    if (!this.connection) {
      throw new Error('Not initialized');
    }

    const orgEntities = await collectOrgEntities(this.config, this.logger, this.cache)

    let catalogEntities: SystemEntity[] = []
    let productEntities: ProductEntity[] = []
    let apiEntities: ApiEntity[] = []
    for (const orgEntity of orgEntities) {
      const orgName = orgEntity.metadata.name
      const nextCatalogEntities = await collectCatalogEntities(this.config, this.logger, this.cache, orgName)
      for (const catalogEntity of nextCatalogEntities) {
        apiEntities = [...apiEntities, ...await collectAPIEntities(this.config, this.logger, this.cache, orgName, catalogEntity.metadata.name)]
        productEntities = [...productEntities, ...await collectProductEntities(this.config, this.logger, this.cache, orgName, catalogEntity.metadata.name)]
      }
      catalogEntities = [...catalogEntities, ...nextCatalogEntities]
    }

    const results = [createAPICDomain(), createInstanceDomain(this.env), ...orgEntities, ...apiEntities, ...catalogEntities, ...productEntities]
    this.logger.debug(JSON.stringify(results, null, 2))

    await this.connection.applyMutation({
      type: 'full',
      entities: results.map(entity => {
        return {
          entity: entity,
          locationKey: `${this.env}:default`
        }
      })
    })
  }
}
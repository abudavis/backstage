/********************************************************* {COPYRIGHT-TOP} ***
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corporation 2024
 *
 * All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 ********************************************************** {COPYRIGHT-END} **/
import {
  coreServices,
  createBackendModule,
} from '@backstage/backend-plugin-api';
import { loggerToWinstonLogger } from "@backstage/backend-common";

import { catalogProcessingExtensionPoint } from '@backstage/plugin-catalog-node/alpha';
import { ApicProvider } from './providers';
import { ProductProcessor } from './processors/ProductProcessor';

export const ibmModuleApic = createBackendModule({
  pluginId: 'catalog',
  moduleId: 'apic',
  register(reg) {
    reg.registerInit({
      deps: {
        catalog: catalogProcessingExtensionPoint,
        config: coreServices.rootConfig,
        logger: coreServices.logger,
        scheduler: coreServices.scheduler,
        cache: coreServices.cache
      },
      async init({ catalog, config, logger, scheduler, cache }) {
        logger.info('Registering IBM APIC Provider Module')
        catalog.addProcessor(new ProductProcessor())
        catalog.addEntityProvider(
          ApicProvider.fromConfig(config, {
            logger: logger,
            scheduler: scheduler,
            schedule: scheduler.createScheduledTaskRunner({
              frequency: { minutes: 5 },
              timeout: { seconds: 30 },
            }),
            cache: cache,
          })
        )
      },
    });
  },
});

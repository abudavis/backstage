IBM API Connect Backstage Plugin:

IBM API Connect Backstage Plugin (apic-backstage) is a plugin for backstage that provides a centralized view of all your APIs and products across multiple API Connect (APIC) clouds, provider organizations, and catalogs.

Package contents:

- README.txt - This readme file
  
- ibm-apic-backstage-plugin.tar.gz - Tar file containing the Backstage Plugin, this will need to be unpacked to the backstage plugins directory

- license - license files 

Usage / Documentation:

For detailed instructions on how to install and configure the backstage plugin, view the documentation at https://www.ibm.com/docs/SSMNED_v10cd??topic=dpsya-technology-preview-using-api-connect-backstage-plug-in or consult the Readme.md included in the Backstage Plugin tar 

Version:

0.1.0
